apt update

apt upgrade

apt install git

pkg install python3

pip3 install rsa

pip3 install thrift==0.11.0

pip3 install requests

pip3 install bs4

pip3 install gtts

pip3 install pytz

pip3 install humanfriendly

pip3 install googletrans

pkg install nano

git clone https://github.com/Emclub/botLineEm

Nano Tes.py    (Edit MID)

cd botLineEm

PYThon3 Tes.py
